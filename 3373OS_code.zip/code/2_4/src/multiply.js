module.exports = function (left, right) {
  return left * right;
};
